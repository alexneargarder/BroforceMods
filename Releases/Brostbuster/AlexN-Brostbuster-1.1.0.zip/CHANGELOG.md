## v1.1.0
- Changes for BroMaker update.
- Shorten proton charge up when resuming firing.
- Allow ghost trap to capture projectiles and grenades.
- Add other brostbusters.
- Adjust damage against bosses / vehicles.

## v1.0.3
- Fixed Ghost Trap being unable to hit players even if they can damage each other in the current gamemode.
- Changes for BroMaker update.

## v1.0.2
- Improved load time.

## v1.0.1
- Fixed audio bug with Ghost Trap.

## v1.0.0
- Release
