## v1.0.1
- Fix lives counter not updating for all players.
- Allow other players to immediately join on the join screen rather than requiring them to join via drop in.

## v1.0.0 
- Initial release
