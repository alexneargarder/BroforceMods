## v1.0.3
- Updated to work with new RocketLib version.
- Fix players being able to be trapped in hell portal in competitive mode if they don't currently have enough points to attempt a win.
- Allow double tapping to sprint as ghosts.
- Fix ladder climbing animation for pig and satan miniboss.

## v1.0.2
- Updated to work with new RocketLib version.
- Fixed elite bruiser not dealing damage when doing elbow slam.
- Added satan avatar.

## v1.0.1
- Various bug fixes.
- Added option for increasing heavy enemy jump height.
- Added options for applying handicaps in competitive mode.

## v1.0.0
- Release
