## v1.1.1
- Fix linux compatibility issue.
- Update variant icons to work with new BroMaker update.

## v1.1.0
- Changes for BroMaker update.
- Added option to not carry over death in IronBro mode.
- Allow special to hit nearby enemies.
- Improved sound effects.
- Fixed gunsprite looking weird when firing on a zipline.

## v1.0.5
- Changes for BroMaker update.

## v1.0.4
- Improved load time.

## v1.0.3
- Fixed issues caused by BroMaker update.

## v1.0.2
- Removed life cost for transforming into the thing.
- Reduced thing special charges.
- Buffed thing attack damage.

## v1.0.1
- Increased melee damage in human form
- Increased thing's special charges to 4
- Fixed animation bugs when throwing grenades and rescuing a bro

## v1.0.0
- Release
