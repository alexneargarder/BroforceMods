## v2.0.5
- Fixed randomization applying to Tank Bro's tank and the mech airdrop powerup.

## v2.0.4
- Fixed broken flex power.

## v2.0.3
- Added option for randomizing ammo crates

## v2.0.2
- Fixed enemies that cause level end triggers being able to turn into Sandworms.
