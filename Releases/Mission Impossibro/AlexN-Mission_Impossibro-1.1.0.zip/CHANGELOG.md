## v1.1.0
- Changes for BroMaker update.
- Added option to set keybinding to toggle grapple.
- Added option to disable jump from toggling grapple.
- Added ability to climb along ceiling.
- Rebalanced explosives and explosive gum.

## v1.0.6
- Changes for BroMaker update.

## v1.0.5
- Improved load time.

## v1.0.4
- Made special prevent dogs and other enemies from hearing attacks / landing.
- Fixed detonator noise playing multiple times when rescuing a bro.

## v1.0.3
- Fixed issues with gunsprite on ziplines.

## v1.0.2
- Added explosive gum melee.
- Added balaclava to avatar when using special.
- Fixed Gun Sprite alignment.
- Made tranq gun fire lower when crouching.

- Fixed special ammo not flashing when empty.

## v1.0.1
- Fixed detonator click playing after death.

## v1.0.0
- Release
