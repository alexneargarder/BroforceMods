## v1.0.2
- Updated to work with new RocketLib version.
- Fixed elite bruiser not dealing damage when doing elbow slam.
- Added satan avatar.

## v1.0.1
- Various bug fixes.
- Added option for increasing heavy enemy jump height.
- Added options for applying handicaps in competitive mode.

## v1.0.0
- Release
