## v1.1.0
- Changes for BroMaker update.
- Improved pickup animation.
- Allow other bros to drive war rig.

## v1.0.3
- Fixed bug with Furiosa being unable to pilot War Rig in multiplayer in some cases.
- Changes for BroMaker update.

## v1.0.2
- Improved load time.

## v1.0.1
- Fixed holding mooks on helicopter ladder.
- Fixed switching weapons affecting dead Furibrosas.
- Increased grab range backwards slightly.
- Slightly increased damage taken by War Rig when hitting enemies.

## v1.0.0
- Release
