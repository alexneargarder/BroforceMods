## v2.1.5
- Fix bug with errors being thrown sometimes when enabling / disabling BroMaker bros.
- Handle BroMaker custom bro unlocks better.
- Switch to using RocketLib for keybindings.

## v2.1.4
- Changes for BroMaker update.
- Fix not handling only custom characters in Iron Bro setting for BroMaker.

## v2.1.3
- Fixed bug with having only one bro enabled.
- Added option to include unfinished bros.
- Added additional error handling.

## v2.1.2
- Fixed issue with Ignore Forced Bros option

## v2.1.1
- Added option to sort bro list.
- Added option to use vanilla randomization.
- Added option to ignore forced bros on certain levels.

## v2.1.0
- Added option to filter bros
- Fixed being able to swap bros while in mech, causing a duplicate character to spawn

## v2.0.7
- Updated to work with latest BroMaker update.

## v2.0.6
- Fixed small bug with BroMaker compatibility

## v2.0.5
- Added support for BroMaker bros.
- Made it so only available bros show in IronBro.

## v2.0.4
- Minor UI changes

## v2.0.3
- Added support for keybinds.
- Added support for 4 local players.
- Added option for adjusting swap cooldown time.
- Fixed swapping characters removing momentum.

## v2.0.2
- Added new bros from the update.

## v2.0.1
- Fixed a small bug with being unable to swap to BroLee in IronBro.
